package com.trainer;

public class Invoice {

    private String number;
    private final double amountToPay;    // Encapsulation: this value is not exposed to other classes (not even through a public method)
    private double discount;             // Encapsulation: this value is not exposed to other classes (not even through a public method)

    /**
     * Constructor that accepts the discount.
     */
    public Invoice(String number, double amountToPay, double discount) {
        setNumber(number);
        this.amountToPay = amountToPay;
        setDiscount(discount);
    }

    /**
     * Another constructor that does not accept any discount.
     */
    public Invoice(String number, double amountToPay) {
        this(number, amountToPay, 0.0);    // A call to the upper constructor
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        // Check whether invoice number length is less than 10 symbols. Otherwise cut it to 10 symbols:
        if (number.length() > 10) {
            number = number.substring(0, 10);
        }
        // And then assign the final value of invoice number to the instance's field:
        this.number = number;
    }

    public void setDiscount(double discount) {
        // Adjust the discount before assigning it to instance's field:
        // We check that its value falls between 0% (0.0) and 100% (1.0)

        double minDiscount = 0.0;
        double maxDiscount = 1.0;

        if (discount < minDiscount) {
            discount = minDiscount;
        } else if (discount > maxDiscount) {
            discount = maxDiscount;
        }

        this.discount = discount;
    }

    /**
     * Return the discounted amount based on fields: 'amountToPay' and 'discount'.
     * ! Encapsulation: Those fields do not get exposed to other classes on their own !
     */
    public double getAmountToPay() {
        return amountToPay - amountToPay * discount;

        // if discount is of type int:
        // return amountToPay - amountToPay * discount / 100.0
    }
}
