package com.trainer;

public class Main {

    public static void main(String[] args) {
        Invoice invoice1 = new Invoice("ABC-0001", 40.0);         // create instance of Invoice class without discount
        Invoice invoice2 = new Invoice("ABC-000297987987987987", 130.99, 0.1);  // create instance of Invoice class with discount
        Invoice invoice3 = new Invoice("ABC-2093482039482039", 400.0, -0.25);  // Accountant entered negative discount
        Invoice invoice4 = new Invoice("ABC-17422", 400.0, 1.5);  // Accountant entered discount that is greater than 100%
        // .....
        System.out.println("invoice1: " + invoice1.getNumber() + ", amount = " + invoice1.getAmountToPay());
        System.out.println("invoice2: " + invoice2.getNumber() + ", amount = " + invoice2.getAmountToPay());
        System.out.println("invoice3: " + invoice3.getNumber() + ", amount = " + invoice3.getAmountToPay());
        System.out.println("invoice4: " + invoice4.getNumber() + ", amount = " + invoice4.getAmountToPay());
    }
}
